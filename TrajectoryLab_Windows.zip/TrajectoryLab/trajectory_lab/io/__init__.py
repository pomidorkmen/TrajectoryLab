"""Input and output adapters."""
