"""Run the desktop UI by default; retain CLI and packaged UI smoke test modes."""

from __future__ import annotations

import sys

from trajectory_lab.cli import main as cli_main

if __name__ == "__main__":
    if len(sys.argv) == 1:
        from trajectory_lab.ui.app import run_gui

        raise SystemExit(run_gui())
    if sys.argv[1:] == ["--ui-smoke-test"]:
        from trajectory_lab.ui.app import run_ui_smoke_test

        raise SystemExit(run_ui_smoke_test())
    raise SystemExit(cli_main())
