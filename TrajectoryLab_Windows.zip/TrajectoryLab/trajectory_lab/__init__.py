"""TrajectoryLab: reproducible low-speed particle-motion research tools."""

__version__ = "0.4.2"
